using System.Collections;
using System.Collections.Generic;

using UnityEngine;

public class Bullet : MonoBehaviour
{

   public float damage = 1f;

   private ImpactEffect bulletEffect;

   void Start()
   {
       bulletEffect = new ImpactEffect();
   }
   
   private void OnCollisionEnter(Collision collision)
   {
        if (collision.gameObject.CompareTag("Target"))
        {
           //bullet hole effect
           bulletEffect.CreateBulletImpactEffect(collision);

           DamageTargetIfHit(collision);

           //get rid of dah bullet
           Destroy(gameObject);
        }
   }

   private void DamageTargetIfHit(Collision collision) 
   {
        Target target = collision.gameObject.transform.GetComponent<Target>();

        //if target script(component) exists, call damage function
        if (target != null)
        {
            print("hit");
            DamageTarget(target);
        }
   }

   private void DamageTarget(Target target)
   {
       //call Target.cs TakeDamage function 
       target.TakeDamage(damage);
   }

   

}
