using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class AiMovement : MonoBehaviour
{

  
    public NavMeshAgent agent;
    public GameObject target;
    public Vector3 offset = new Vector3(5, 5, 0);

  
    void Update()
    {
        agent.SetDestination(target.transform.position - offset);
    
    }
}
