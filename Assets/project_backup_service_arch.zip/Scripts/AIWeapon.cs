

using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Reflection;
using UnityEngine;


public class AIWeapon : MonoBehaviour, Weapon
{

    public bool isShooting, hasNotFired; 
    
    public float shootingDelay = 2f;

    public float spreadIntensity;

    public Camera aiCamera;

    public GameObject aiObject; 

    public GameObject target;

    public GameObject gun; 

    public GameObject bulletPrefab;
    
    public Transform bulletSpawn;

    public float bulletVelocity = 30f;
    
    public float bulletPrefabLifeTime = 1.5f;

    public float spreadOverTimeModifier = 1f;

    public float clipSize = 60.0f;     

    public float reloadTime = 10f;

    public ShootingMode currentShootingMode;

    public float holdTriggerFor = 1.5f;

    public float timeBetweenBursts = 0.1f;

    bool allowReset = true;

    private float triggerHeldTime = 1f;

    private bool resetting = false;

    private float bulletsLeft;

    private float reloadTimer;

    private Quaternion targetRotation; 

    private void Awake()
    {
        hasNotFired = true;
        bulletsLeft = clipSize;
        reloadTimer = reloadTime; 
      
    }
    

   
  
    void Update()
    {
        LookAt();
       
        SetShootingLogic();

        bool isClipEmpty = IsClipEmpty();
        
        bool isLineOfSight = IsLineOfSight();

        if (hasNotFired && isShooting && !isClipEmpty && isLineOfSight)
        {
            
            FireWeapon();
        }

        if (isClipEmpty)
        {
            Reload();
        }

      
    }

    private bool IsLineOfSight()
    {

        
        Vector3 directionToTarget = ServiceManager.physicsService.GetDirectionFromTransformPosition(gun.transform, target.transform);
        //Vector3 targetPoint = Vector3.Scale(aiCamera.transform.forward, targetRotation.eulerAngles);
        return ServiceManager.raycastService.isRayHitObjectOfType<PlayerMovement>(bulletSpawn.position, directionToTarget, 10000);
    }

 

    private void LookAt()
    {

        targetRotation = ServiceManager.physicsService.QuaternionFromTwoTransforms(gun.transform, target.transform);
        
        // Smoothly interpolate to the target rotation
        aiCamera.transform.rotation = Quaternion.Slerp(aiCamera.transform.rotation, targetRotation, Time.deltaTime * 40);
        aiObject.transform.rotation = Quaternion.Slerp(aiObject.transform.rotation, targetRotation, Time.deltaTime * 40);
        gun.transform.rotation = Quaternion.Slerp(gun.transform.rotation, targetRotation, Time.deltaTime * 40);
        //bulletSpawn.rotation =  Quaternion.Slerp(bulletSpawn.rotation, targetRotation, Time.deltaTime * 40);


    }

   

    private void SetShootingLogic()
    {
        if (currentShootingMode == ShootingMode.Auto)
        {
            SetIsShootingTriggerHeld();
            TriggerHeldIncrementOrReset();
           
        }
        else if (currentShootingMode == ShootingMode.Single)
        {
            // isShooting = true; 
        }
    }

    private void SetIsShootingTriggerHeld()
    {
        if (triggerHeldTime > holdTriggerFor)
        {
            isShooting = false;
        }
        else
        {
            isShooting = true;
        }

    }

    private void TriggerHeldIncrementOrReset()
    {
        if (isShooting)
        {
            triggerHeldTime += 0.1f;
        }
        else
        {
           
            if (!resetting)
            {
                StartCoroutine(ResetTriggerHeld(timeBetweenBursts));
                resetting = true;
            }
        }
    }

    private IEnumerator ResetTriggerHeld(float delay)
    {
        yield return new WaitForSeconds(delay);
        
        triggerHeldTime = 1f;
        resetting = false;
        
    }

    private bool IsClipEmpty()
    {
        return bulletsLeft <= 0;
    }

    private void FireWeapon()
    {

        GameObject bullet = LaunchBulletAtTarget();

        SetBulletFired();

        StartCoroutine(DestroyGameObjectAfterTime(bullet, bulletPrefabLifeTime));

        if (allowReset)
        {
            Invoke("ResetShot", shootingDelay);
            //Switches true when this coroutine is finished 
            allowReset = false;
        }
    }

    private GameObject LaunchBulletAtTarget()
    {
        Vector3 direction = target.transform.position - bulletSpawn.position;

        //add spread to vector which the bullet follows 
        Vector3 shootingDirection = ServiceManager.physicsService.CalculateRandomVectorAtDirection(direction,
            spreadIntensity, triggerHeldTime * spreadOverTimeModifier).normalized;

        GameObject bullet = ServiceManager.prefabService.InstantiatePrefab(bulletPrefab, bulletSpawn.position);

        ServiceManager.prefabService.LaunchPrefab(bullet, bulletSpawn.forward + shootingDirection, bulletVelocity);

        return bullet; 
    }

    private void SetBulletFired()
    {
        bulletsLeft--;
        hasNotFired = false;

    }
   
    private IEnumerator DestroyGameObjectAfterTime(GameObject gameObject, float delay)
    {
        yield return new WaitForSeconds(delay);
        Destroy(gameObject);
    }

    private void ResetShot()
    {
        hasNotFired = true;
        allowReset = true;
    }

    private void Reload()
    {
        reloadTimer--;
        if (reloadTimer <= 0)
        {
            reloadTimer = reloadTime;
            bulletsLeft = clipSize;
            triggerHeldTime = 1f;
        }
    }   
}
