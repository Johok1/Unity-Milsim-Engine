using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Reflection;
using UnityEngine;

public class TestWeapon : MonoBehaviour, Weapon
{
  
    public Camera playerCamera;
    public GameObject player;
    public GameObject bulletPrefab;
    public Transform bulletSpawn;

    public ShootingMode currentShootingMode;

    public float reloadTime = 10f;
    public float bulletVelocity = 30f;
    public float bulletPrefabLifeTime = 1.5f;
    public float spreadOverTimeModifier = 1f;
    public float clipSize = 60.0f;
    public float shootingDelay = 2f;
    public float spreadIntensity = 1f; 

    private bool isShooting, hasNotFired;
    private float bulletsLeft, reloadTimer;

    private bool allowReset = true;
    private float triggerHeldTime = 1f;

    private void Awake()
    {
        hasNotFired = true;
        bulletsLeft = clipSize;
        reloadTimer = reloadTime;

    }

    void Update()
    {

        SetShootingLogic();

        bool isClipEmpty = IsClipEmpty();

        if (hasNotFired && isShooting && !isClipEmpty)
        {
            FireWeapon();
        }

        if (isClipEmpty)
        {
            Reload();
        }


    }

    private void SetShootingLogic()
    {
        if (currentShootingMode == ShootingMode.Auto)
        {
            SetIsShooting();
            ShootingLogicAuto();

        }
        else if (currentShootingMode == ShootingMode.Single)
        {
            SetIsShooting();
            ShootingLogicSingle();
        }
    }

    private void SetIsShooting()
    {
        isShooting = Input.GetKey(KeyCode.Mouse0);
    }

    private void ShootingLogicAuto()
    {

        if (isShooting)
        {
            triggerHeldTime += 0.1f;
            player.transform.GetComponent<PlayerMovement>().SetSlowEffect(3f * triggerHeldTime);
        }
        else
        {
            player.transform.GetComponent<PlayerMovement>().SetSlowEffect(1f);
            triggerHeldTime = 1f;
        }

    }

    private void ShootingLogicSingle()
    {

    }

    private void Reload()
    {
        reloadTimer--;
        print("reloading");
        if (reloadTimer <= 0)
        {
            reloadTimer = reloadTime;
            bulletsLeft = clipSize;
            triggerHeldTime = 1f;
        }
    }

    private bool IsClipEmpty()
    {
        return bulletsLeft <= 0;
    }

    private void FireWeapon()
    {
      
        SetBulletFired();

        AddGunShakeEffect();

        Vector3 shootingDirection = CalculateDirectionAndSpread().normalized;

        GameObject bullet = FireBulletAtDirection(shootingDirection);


        StartCoroutine(DestroyBulletAfterTime(bullet, bulletPrefabLifeTime));

        if (allowReset)
        {
            Invoke("ResetShot", shootingDelay);
            //Switches true when this coroutine is finished 
            allowReset = false;
        }



    }

    private void SetBulletFired()
    {
        bulletsLeft--;
        hasNotFired = false;

    }

    private void AddGunShakeEffect()
    {
        // Random Shake Quaternion 
        Quaternion shakeRotation = ServiceManager.physicsService.GetRandomShakeQuaternion(spreadIntensity);

        //Get current roatation and apply shake rotation 
        Quaternion targetRotation = player.transform.rotation * shakeRotation;

        //Apply shaked rotation 
        player.transform.rotation = targetRotation;
    }

    


    public Vector3 CalculateDirectionAndSpread()
    {
        //Project ray from viewport offset by 0.5 on x and y 
        Ray ray = playerCamera.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0));

        Vector3 targetPoint = ServiceManager.raycastService.CastRayAtPoint(ray);
        
        //Difference between target vector and bullet vector gives direction from bullet to target 
        Vector3 direction = ServiceManager.physicsService.GetDirectionToVector3(bulletSpawn.position, targetPoint);

        //augment direction vector based on spread intensity and time the trigger is held
        return ApplySpreadOverTime(direction);
    }

    private Vector3 ApplySpreadOverTime(Vector3 direction)
    {
        float spreadX = UnityEngine.Random.Range(-spreadIntensity, spreadIntensity) * (triggerHeldTime * spreadOverTimeModifier);
        float spreadY = UnityEngine.Random.Range(-spreadIntensity, spreadIntensity) * (triggerHeldTime * spreadOverTimeModifier);


        return direction + new Vector3(spreadX, spreadY, 0);
    }

  

    

    private GameObject FireBulletAtDirection(Vector3 shootingDirection)
    {
        //create bullet at bullet spawn position with default rotation 
        GameObject bullet = Instantiate(bulletPrefab, bulletSpawn.position,
            Quaternion.identity);

        //rotate bullet towards shooting direction 
        bullet.transform.forward = shootingDirection;

        //add force to rigidbody component scaled by the bulletVelocity modifier 
        bullet.GetComponent<Rigidbody>().AddForce((bulletSpawn.forward.normalized + shootingDirection) * bulletVelocity,
            ForceMode.Impulse);

        return bullet;
    }

    private IEnumerator DestroyBulletAfterTime(GameObject bullet, float delay)
    {
        yield return new WaitForSeconds(delay);
        Destroy(bullet);
    }

    private void ResetShot()
    {
        hasNotFired = true;
        allowReset = true;
    }    
}
