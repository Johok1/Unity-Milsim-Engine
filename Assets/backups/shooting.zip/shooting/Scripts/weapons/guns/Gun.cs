using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Gun : MonoBehaviour 
{
    public Camera playerCamera;

    public GameObject leftArm; 
    public GameObject player;

    public GameObject hold; 

    public GameObject gun; 
    public GameObject bulletPrefab;
    public Transform bulletSpawn;

    public float reloadTime = 600f;
    public float bulletPrefabLifeTime = 5f;
    public float spreadOverTimeModifier = 0f;
    public float clipSize = 120.0f;
    public float shootingDelay = 2f;
    public float spreadIntensity = 0.1f;

    public float recoilX = 0.02f;

    public float recoilY = -1f;

    public float recoilMultiplierX = 1f;

    public float recoilMultiplierY = 1f; 

    protected bool bulletNotLaunched, isClipEmpty;
    protected float bulletsLeft, reloadTimer;

    private bool allowReset = true;

    private IRecoilEffect recoilEffect;
    private IBulletSpread bulletSpread; 
    private IWeaponController weaponController;
    private IKickbackEffect kickbackEffect;   

    public float shakeIntensity = 0.1f; 

    private bool isRequestingShot;

    public Camera targetCamera; 

    private float triggerHeldTime = 1f;

    private IShootingDirection shootingDirection; 

    public Gun(IRecoilEffect recoilEffect, IBulletSpread bulletSpread, IWeaponController weaponController
        , IKickbackEffect kickbackEffect, IShootingDirection shootingDirection)
    {
        this.recoilEffect = recoilEffect;
        this.bulletSpread = bulletSpread;
        this.weaponController = weaponController; 
        this.kickbackEffect = kickbackEffect;
        this.shootingDirection = shootingDirection;
       
    }
  

    private void Awake()
    {
        bulletNotLaunched = true;
        bulletsLeft = clipSize;
        reloadTimer = reloadTime;

    }

    
    void Start(){
         Cursor.lockState = CursorLockMode.Locked;
       
    }

    private void Update()
    {
         Cursor.visible = false; 
        //implement some sort of input manager, repeat code from MouseLook
        

        isRequestingShot = weaponController.GetWeaponInput();

        UpdateTriggerHeldTime();

        kickbackEffect.UpdateKickbackEffect(this.isRequestingShot, this.player, this.triggerHeldTime);

        isClipEmpty = IsClipEmpty();

        if (isShotReady())
        {
            FireWeapon();
        }

        if (isClipEmpty)
        {
            Reload();
        }

        RotationCode();
        LockZAxisRotation();

    }


    protected virtual bool isShotReady()
    {
        return bulletNotLaunched  && !isClipEmpty && isRequestingShot;
    }

    private void UpdateTriggerHeldTime()
    {
        if (isRequestingShot)
        {
            triggerHeldTime += 0.1f;
        }
        else
        {
            triggerHeldTime = 1f;
        }

    }

    private bool IsClipEmpty()
    {
        return bulletsLeft <= 0;
    }

public float mouseSensitivity = 100f;
private float yRotation = 0f;


private float recoilRelapseSpeed = 0f; 

 void RotationCode(){
        float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity * Time.deltaTime;
        float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity * Time.deltaTime;

        yRotation -= mouseY;

        float xRotation = 0; 
        xRotation += mouseX;
        //clamp y rotation to avoid flipping 
        yRotation = Mathf.Clamp(yRotation, - 90f, 90f);

        //handles up down rotation, which happens on the x axis in euler angles lol
        //transform.localRotation = Quaternion.Euler(yRotation, xRotation, 0f);

        // Get the current local rotation as Euler angles
        Vector3 targetRotation = this.hold.transform.localRotation.eulerAngles;

        // Add the desired yRotation to the current X rotation
        targetRotation.x = yRotation;

        targetRotation.y = xRotation;

     
   
      if(!bulletNotLaunched){
       recoilRelapseSpeed = 10f; 
       
      }else{
       
        recoilRelapseSpeed = 80f; 
      
      }
      if(!Input.GetKey(KeyCode.E)){
      gun.transform.localRotation = Quaternion.RotateTowards(
            gun.transform.localRotation, 
             Quaternion.Euler(targetRotation), 
            Time.deltaTime * recoilRelapseSpeed
        );
         playerCamera.transform.localRotation  = Quaternion.RotateTowards(
            gun.transform.localRotation, 
            Quaternion.Euler(targetRotation.x,0f, 0f), 
            Time.deltaTime * recoilRelapseSpeed
        );
    }else{
       playerCamera.transform.localRotation  = Quaternion.RotateTowards(
            playerCamera.transform.localRotation, 
            Quaternion.Euler(targetRotation.x,0f, 0f), 
            Time.deltaTime * recoilRelapseSpeed
        ); 
    }
     


        
        
        
        //handles left right rotation
        player.transform.Rotate(Vector3.up * mouseX);
    }

    private IEnumerator RelapseSpeed(float speed, float delay)
    {
        yield return new WaitForSeconds(delay);
        this.recoilRelapseSpeed = speed;
    }


     private void LockZAxisRotation()
    {
        Vector3 rotation = playerCamera.transform.eulerAngles;
        rotation.z = 0;
        playerCamera.transform.eulerAngles = rotation;

    }


    private void FireWeapon()
    {
       

      
       
        Vector3 targetPoint = ServiceManager.physicsService.GetPositionCameraPointing(playerCamera);
       
        Vector3 shootingDirect = shootingDirection.CalculateShootingDirection(targetPoint, bulletSpawn.position);

        shootingDirect = bulletSpread.ApplySpreadOverTime(shootingDirect, spreadIntensity, (triggerHeldTime * spreadOverTimeModifier));

        GameObject bullet = Instantiate(bulletPrefab, bulletSpawn.position,
           Quaternion.identity);

        Bullet bulletObj = bullet.GetComponent<Bullet>();
        //need impact not velocity
        GameObject firedBullet = bulletObj.ApplyBulletImpact(bullet, shootingDirect, bulletSpawn);
        
        SetBulletFired();

      
        
        Quaternion recoil= this.recoilEffect.CalculateRecoilRotation
        (this.shakeIntensity, this.recoilX, this.recoilY, this.recoilMultiplierX, this.recoilMultiplierY, this.hold.transform);
      
        this.hold.transform.eulerAngles= Quaternion.RotateTowards(this.hold.transform.rotation,recoil,10f).eulerAngles;
        Vector3 holdEuler = this.hold.transform.rotation.eulerAngles; 
      //  print(holdEuler + " pre clamp");
       // holdEuler.x = Mathf.Clamp(holdEuler.x, 350f, 400f);
        // holdEuler.y = Mathf.Clamp(holdEuler.y, 0f, 300f);
      //  print(holdEuler + " post clamp");
        this.hold.transform.eulerAngles = holdEuler;
        StartCoroutine(DestroyBulletAfterTime(firedBullet, bulletPrefabLifeTime));

        if (allowReset)
        {
            Invoke("ResetShot", shootingDelay);
            allowReset = false;
        }
    }

    private void SetBulletFired()
    {
        bulletsLeft--;
        bulletNotLaunched = false;
    }

     private IEnumerator ResetRotation(float delay)
    {
        yield return new WaitForSeconds(delay);
        this.hold.transform.rotation= Quaternion.Euler(0f,0f,0f);
    }
    private IEnumerator DestroyBulletAfterTime(GameObject bullet, float delay)
    {
        yield return new WaitForSeconds(delay);
        Destroy(bullet);
    }

    private void ResetShot()
    {
        bulletNotLaunched = true;
        allowReset = true;
    }

    protected virtual void Reload()
    {
        reloadTimer--;
        print("reloading");
        if (reloadTimer <= 0)
        {
            reloadTimer = reloadTime;
            bulletsLeft = clipSize;
            triggerHeldTime = 1f;
        }

    }

}
