using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExampleRecoilEffect : IRecoilEffect 
{
    public Quaternion CalculateRecoilRotation(float shakeIntensity, float recoilY, float recoilX, float recoilMultiplierY, 
    float recoilMultiplierX, Transform recoilingObject)
    {
         Quaternion shakeRotation = Quaternion.Euler(recoilX * recoilMultiplierX, recoilY * recoilMultiplierY,0f );
        Quaternion targetRotation = Quaternion.Euler(recoilingObject.rotation.eulerAngles + shakeRotation.eulerAngles);
         targetRotation *= ServiceManager.physicsService.GetRandomShakeQuaternion(shakeIntensity);
      
      return targetRotation;
    }
}
