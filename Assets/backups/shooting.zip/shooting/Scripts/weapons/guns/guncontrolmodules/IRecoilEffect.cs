using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IRecoilEffect {

    Quaternion CalculateRecoilRotation(float shakeIntensity, float recoilY, float recoilX, float recoilMultiplierY, 
    float recoilMultiplierX, Transform recoilingObject); 
}
