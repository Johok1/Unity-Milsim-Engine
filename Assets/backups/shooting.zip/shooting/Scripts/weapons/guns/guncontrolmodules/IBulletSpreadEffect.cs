using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IBulletSpread
{
   Vector3 ApplySpreadOverTime(Vector3 direction, float spreadIntensity, float spreadModifier);
}
