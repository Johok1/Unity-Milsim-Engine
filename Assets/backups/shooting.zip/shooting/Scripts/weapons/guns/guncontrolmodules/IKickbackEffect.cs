using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IKickbackEffect
{
    void UpdateKickbackEffect(bool isRequestingShot, GameObject player, float effectModifier, float baseEffect = 3f);
   
}
