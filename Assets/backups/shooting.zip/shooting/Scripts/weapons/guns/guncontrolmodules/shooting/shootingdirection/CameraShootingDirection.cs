using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraShootingDirection : IShootingDirection
{
    public Vector3 CalculateShootingDirection(Vector3 targetPoint, Vector3 bulletPosition){
            return ServiceManager.physicsService.GetDirectionToVector3(bulletPosition, targetPoint);
    }
}
