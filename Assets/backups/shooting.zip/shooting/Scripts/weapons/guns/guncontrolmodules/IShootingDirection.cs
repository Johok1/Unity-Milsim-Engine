using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IShootingDirection
{
    Vector3 CalculateShootingDirection(Vector3 targetPoint, Vector3 bulletPosition);
   
}
