using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using UnityEngine;

public class MouseLook : MonoBehaviour
{
    public float mouseSensitivity = 100f;

    private float yRotation = 0f;

    public Transform playerBody;

    public GameObject gun; 

    public Camera mainCamera; 

    void Start()
    {
       // Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false; 
    }

    void RotationCode(){
           float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity * Time.deltaTime;
        float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity * Time.deltaTime;

        yRotation -= mouseY;

        float xRotation = 0; 
        xRotation += mouseX;
        //clamp y rotation to avoid flipping 
        yRotation = Mathf.Clamp(yRotation, - 90f, 90f);

        //handles up down rotation, which happens on the x axis in euler angles lol
        //transform.localRotation = Quaternion.Euler(yRotation, xRotation, 0f);

        // Get the current local rotation as Euler angles
        Vector3 targetRotation = gun.transform.localRotation.eulerAngles;

        // Add the desired yRotation to the current X rotation
        targetRotation.x = yRotation;

        targetRotation.y = xRotation;

     
        // Smoothly rotate towards the target rotation
        gun.transform.localRotation = Quaternion.RotateTowards(
            gun.transform.localRotation, 
             Quaternion.Euler(targetRotation), 
            Time.deltaTime * 10f
        );

        mainCamera.transform.localRotation  = Quaternion.RotateTowards(
            gun.transform.localRotation, 
             Quaternion.Euler(targetRotation), 
            Time.deltaTime * 10f
        );
        
        //handles left right rotation
        playerBody.Rotate(Vector3.up * mouseX);
    }

    void Update()
    {
     

       
    }


   

    

}