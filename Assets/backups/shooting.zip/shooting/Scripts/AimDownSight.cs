using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AimDownSight : MonoBehaviour
{

    public Transform aimPosition;

    public Transform returnPosition;

    public Camera camera; 

    public GameObject playerObj; 

    private float oldIntensity; 


    // Start is called before the first frame update
    void Start()
    {
        oldIntensity = GetComponent<Gun>().mouseSensitivity;
    }

    bool IsAimInput(){
        return Input.GetKey(KeyCode.Mouse1);
    }

    void TranslateCameraToSight(){
        camera.transform.position = aimPosition.position;
        camera.fieldOfView = 20f;

    }

    void ReturnCamera(){
        camera.transform.position = returnPosition.position;
        camera.fieldOfView = 105f; 
        GetComponent<Gun>().mouseSensitivity = oldIntensity; 

    }

    void LookCloser(){
        camera.fieldOfView = 5f; 
        GetComponent<Gun>().mouseSensitivity = 25f; 
    }

    

    // Update is called once per frame
    void FixedUpdate()
    {
        if(IsAimInput()){
            TranslateCameraToSight();
            if(Input.GetKey(KeyCode.Q)){
                LookCloser();
                
            }
            
        }else{
            ReturnCamera();
        }
    }
}
