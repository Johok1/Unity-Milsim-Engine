using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Gun : MonoBehaviour 
{
    public Camera playerCamera;
    public GameObject player;
    public GameObject bulletPrefab;
    public Transform bulletSpawn;

    public float reloadTime = 600f;
    public float bulletPrefabLifeTime = 5f;
    public float spreadOverTimeModifier = 0f;
    public float clipSize = 120.0f;
    public float shootingDelay = 2f;
    public float spreadIntensity = 0.1f;

    public float recoilIntensity = 1f; 

    protected bool bulletNotLaunched, isClipEmpty;
    protected float bulletsLeft, reloadTimer;

    private bool allowReset = true;

    private IRecoilEffect recoilEffect;
    private IBulletSpread bulletSpread; 
    private IWeaponController weaponController;
    private IKickbackEffect kickbackEffect;
   

    private bool isRequestingShot;

    private float triggerHeldTime = 1f;

    public Gun(IRecoilEffect recoilEffect, IBulletSpread bulletSpread, IWeaponController weaponController
        , IKickbackEffect kickbackEffect)
    {
        this.recoilEffect = recoilEffect;
        this.bulletSpread = bulletSpread;
        this.weaponController = weaponController; 
        this.kickbackEffect = kickbackEffect;
       
    }
  

    private void Awake()
    {
        bulletNotLaunched = true;
        bulletsLeft = clipSize;
        reloadTimer = reloadTime;

    }

    private void Update()
    {

        isRequestingShot = weaponController.GetWeaponInput();

        UpdateTriggerHeldTime();

        kickbackEffect.UpdateKickbackEffect(this.isRequestingShot, this.player, this.triggerHeldTime);

        isClipEmpty = IsClipEmpty();

        if (isShotReady())
        {
            FireWeapon();
        }

        if (isClipEmpty)
        {
            Reload();
        }


    }


    protected virtual bool isShotReady()
    {
        return bulletNotLaunched  && !isClipEmpty && isRequestingShot;
    }

    private void UpdateTriggerHeldTime()
    {
        if (isRequestingShot)
        {
            triggerHeldTime += 0.1f;
        }
        else
        {
            triggerHeldTime = 1f;
        }

    }

    private bool IsClipEmpty()
    {
        return bulletsLeft <= 0;
    }

    private void FireWeapon()
    {
       

      
       
        Vector3 targetPoint = ServiceManager.physicsService.GetPositionCameraPointing(playerCamera);

        Vector3 shootingDirection = ServiceManager.physicsService.GetDirectionToVector3(bulletSpawn.position, targetPoint);

        shootingDirection = bulletSpread.ApplySpreadOverTime(shootingDirection, spreadIntensity, (triggerHeldTime * spreadOverTimeModifier));

        GameObject bullet = Instantiate(bulletPrefab, bulletSpawn.position,
           Quaternion.identity);

        Bullet bulletObj = bullet.GetComponent<Bullet>();
        //need impact not velocity
        GameObject firedBullet = bulletObj.ApplyBulletImpact(bullet, shootingDirection, bulletSpawn);
        
        SetBulletFired();

        this.player.transform.rotation = this.recoilEffect.CalculateRecoilRotation(this.recoilIntensity, this.triggerHeldTime, this.player.transform);
      
        StartCoroutine(DestroyBulletAfterTime(firedBullet, bulletPrefabLifeTime));

        if (allowReset)
        {
            Invoke("ResetShot", shootingDelay);
            allowReset = false;
        }
    }

    private void SetBulletFired()
    {
        bulletsLeft--;
        bulletNotLaunched = false;
    }

    private IEnumerator DestroyBulletAfterTime(GameObject bullet, float delay)
    {
        yield return new WaitForSeconds(delay);
        Destroy(bullet);
    }

    private void ResetShot()
    {
        bulletNotLaunched = true;
        allowReset = true;
    }

    protected virtual void Reload()
    {
        reloadTimer--;
        print("reloading");
        if (reloadTimer <= 0)
        {
            reloadTimer = reloadTime;
            bulletsLeft = clipSize;
            triggerHeldTime = 1f;
        }

    }

}
