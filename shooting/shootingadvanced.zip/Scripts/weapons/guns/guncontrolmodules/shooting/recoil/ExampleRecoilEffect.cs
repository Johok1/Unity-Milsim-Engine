using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExampleRecoilEffect : IRecoilEffect 
{
    public Quaternion CalculateRecoilRotation(float recoilIntensity, float recoilIntensityModifier, Transform recoilingObject)
    {
        Quaternion shakeRotation = ServiceManager.physicsService.GetRandomShakeQuaternion(recoilIntensity);
        Quaternion targetRotation = recoilingObject.rotation * shakeRotation;

        return targetRotation;
      
    }
}
