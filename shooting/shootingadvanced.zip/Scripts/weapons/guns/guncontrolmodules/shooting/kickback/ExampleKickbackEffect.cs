using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExampleKickbackEffect : IKickbackEffect
{
    public void UpdateKickbackEffect(bool isRequestingShot, GameObject player, float effectModifier, float baseEffect = 3f)
    {
        if (isRequestingShot)
        {
            player.transform.GetComponent<PlayerMovement>().SetKickbackEffect(baseEffect * effectModifier);
        }
        else
        {
            player.transform.GetComponent<PlayerMovement>().SetKickbackEffect(1f);
        }
    }
}
