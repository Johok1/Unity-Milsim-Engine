using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HoldInputController : IWeaponController
{
   public bool GetWeaponInput()
    {
        return Input.GetKey(KeyCode.Mouse0); 
    }
}
