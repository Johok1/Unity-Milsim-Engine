using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Reflection;
using UnityEngine;

public class MachineGun : Gun
{
  
    public MachineGun() : base(new ExampleRecoilEffect(), new ExampleBulletSpread(), new HoldInputController(), new ExampleKickbackEffect()) {}
    
}
