using System.Collections;
using System.Collections.Generic;

using UnityEngine;

public class Bullet : MonoBehaviour
{

   public float damage = 1f;

   public float grains = 55f; 

   public float initialVelocity = 991f;

   private ImpactEffect bulletEffect;

  public float bulletCalliber = 5.56f; 

  private bool bulletAlive = false;

    private GameObject bullet;
    private Transform bulletSpawn;
    private Vector3 shootingDirection; 

   void Start()
   {
       bulletEffect = new ImpactEffect();
   }

   void FixedUpdate(){
        Vector3 gravity = new Vector3(0,-9.81f,0);
        if (bulletAlive)
        {
            //rigidbody has its own gravity 
           // gameObject.GetComponent<Rigidbody>().velocity += gravity;
          //  ApplyBulletDrag(bullet, shootingDirection, bulletSpawn);
        }
   }

   private void OnCollisionEnter(Collision collision)
   {
        if (collision.gameObject.CompareTag("Target"))
        {
           //bullet hole effect
           bulletEffect.CreateBulletImpactEffect(collision);

           DamageTargetIfHit(collision);

           //get rid of dah bullet
           Destroy(gameObject);
           bulletAlive = false;
        }
   }

   public GameObject ApplyBulletImpact(GameObject bullet, Vector3 shootingDirection, Transform bulletSpawn)
    {
        this.bullet = bullet;
        this.shootingDirection = shootingDirection;
        this.bulletSpawn = bulletSpawn; 
       float feetPerSecond = initialVelocity * 3.28084f; 
       float muzzleEnergy = (this.grains*(feetPerSecond*feetPerSecond))/450240f;
       //convert from ft-lbs to joule
       muzzleEnergy = muzzleEnergy*1.35582f; 
       //divide muzzle energy by common 20 inch (0.508m) barrel length for force
       float force = muzzleEnergy/0.508f; 
       //bulletVelocity / barrel length will give time in s in barrel, times force will give impulse
       float timeInBarrel = 0.508f/initialVelocity;
       

       float impulse = force * timeInBarrel; 

       bullet.transform.forward = shootingDirection;

       //currently applying velocity as an impulse - inaccurate bullet physics
       bullet.GetComponent<Rigidbody>().AddForce((bulletSpawn.forward.normalized + shootingDirection) * impulse,
        ForceMode.Impulse);
        bulletAlive = true; 
      

       return bullet;
    }

    private void ApplyBulletDrag(GameObject bullet, Vector3 shootingDirection, Transform bulletSpawn){
        
        bullet.GetComponent<Rigidbody>().AddForce(CalculateBulletDrag(shootingDirection, bulletSpawn),
            ForceMode.Force);

    }

    private Vector3 CalculateBulletDrag(Vector3 shootingDirection, Transform bulletSpawn)
    {
        //includes metric conversions 
        float feetPerSecond = initialVelocity * 3.28084f; 
        float dynamicPressure = 0.5f*(0.002377f*(feetPerSecond*feetPerSecond));
        //convert to pascal 
        dynamicPressure = dynamicPressure * 47.8803f; 
        float inte = (bulletCalliber*0.0393701f)/24; 
        inte = inte * inte;
        float frontalArea = Mathf.PI*inte;
        //convert to metric
        frontalArea = 0.092903f*frontalArea; 
        //convert to grams 
        float grams = grains*0.0647989f; 
        float i = 1f;
        float bulletCallibeInches = bulletCalliber * 0.04f;
        float sectionalDensity = grams/(bulletCalliber*bulletCalliber);

        float dragCoefficient = 8/(sectionalDensity*Mathf.PI*(initialVelocity*initialVelocity)*(bulletCalliber*bulletCalliber));
        float drag = frontalArea*dragCoefficient*dynamicPressure;
        return (-(bulletSpawn.forward.normalized+shootingDirection))*drag;
    }

   private void DamageTargetIfHit(Collision collision) 
   {
        Target target = collision.gameObject.transform.GetComponent<Target>();

        //if target script(component) exists, call damage function
        if (target != null)
        {
            print("hit");
            DamageTarget(target);
        }
   }

   private void DamageTarget(Target target)
   {
       //call Target.cs TakeDamage function 
       target.TakeDamage(damage);
   }

   

}
