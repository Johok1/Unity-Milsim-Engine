using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{

    public CharacterController controller;

    public float speed = 12f; 

    public float gravity = -9.81f;

    public Transform groundCheck;

    public float groundDistance = 0.4f;
   
    public LayerMask groundMask;

    public float jumpHeight = 3f;



    private float KickbackEffect = 1f;

    private Vector3 velocity;

    private bool isGrounded;



    void Update()
    {
        UpdateIsGrounded();

        InputMovePlayer();

        LockZAxisRotation();

        InputJumpIfGrounded();

        ApplyGravity();

    }

    //This is accessed by the weapon class to slow the player while shooting 
    public void SetKickbackEffect(float KickbackEffect)
    {
        this.KickbackEffect = KickbackEffect;
    }


    private void UpdateIsGrounded()
    {
        isGrounded = Physics.CheckSphere(groundCheck.position, groundDistance, groundMask);
    }

    private void InputMovePlayer()
    {

        Vector3 move =  GetMovementVectorFromInput();

        //Multiply by Time.deltaTime to make movements
        //frame-rate independent
        controller.Move(((move * speed) / KickbackEffect) * Time.deltaTime);
    }

    private Vector3 GetMovementVectorFromInput()
    {
        float x = Input.GetAxis("Horizontal");
        float y = Input.GetAxis("Vertical");

        Vector3 move = transform.right * x + transform.forward * y;

        return move;
    }

    private void LockZAxisRotation()
    {
        Vector3 rotation = gameObject.transform.eulerAngles;
        rotation.z = 0;
        gameObject.transform.eulerAngles = rotation;

    }

    private void InputJumpIfGrounded()
    {
        if (Input.GetKeyDown(KeyCode.Space) && isGrounded)
        {
            velocity.y = Mathf.Sqrt(jumpHeight * -2 * gravity);

        }
    }

    private void ApplyGravity()
    {
        velocity.y += gravity * Time.deltaTime;
        //multiply by time twice because gravity is
        //an acceleration, time squared 
        controller.Move(velocity * Time.deltaTime);
    }

   

   

   

    /*
    * Legacy function, not sure if needed 
    */
    private void KeepGrounded()
    {

        if (isGrounded && velocity.y < 0)
        {
            velocity.y = -2f;
        }
    }

}