using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AimDownSight : MonoBehaviour
{

    public Transform aimPosition;

    public Transform returnPosition;

    public Camera camera; 

    // Start is called before the first frame update
    void Start()
    {
        
    }

    bool IsAimInput(){
        return Input.GetKey(KeyCode.Mouse1);
    }

    void TranslateCameraToSight(){
        camera.transform.position = aimPosition.position;
        camera.fieldOfView = 20f; 
    }

    void ReturnCamera(){
        camera.transform.position = returnPosition.position;
        camera.fieldOfView = 90f; 
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if(IsAimInput()){
            TranslateCameraToSight();
        }else{
            ReturnCamera();
        }
    }
}
