using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using UnityEngine;

public class MouseLook : MonoBehaviour
{
    public float mouseSensitivity = 100f;

    private float yRotation = 0f;

    public Transform playerBody;

    public GameObject gun; 

    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
    }

    void Update()
    {
        float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity * Time.deltaTime;
        float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity * Time.deltaTime;

        yRotation -= mouseY;

        //clamp y rotation to avoid flipping 
        yRotation = Mathf.Clamp(yRotation, - 90f, 90f);

        //handles up down rotation, which happens on the x axis in euler angles lol
        transform.localRotation = Quaternion.Euler(yRotation, 0f, 0f);

        //handles gun rotation up down
        gun.transform.localRotation = Quaternion.Euler(yRotation, 0f, 0f);

        //handles left right rotation
        playerBody.Rotate(Vector3.up * mouseX);

       
    }


   

    

}