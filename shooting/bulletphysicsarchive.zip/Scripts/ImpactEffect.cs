using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ImpactEffect : MonoBehaviour
{


    public void CreateBulletImpactEffect(Collision collision)
    {
        ContactPoint contact = collision.contacts[0];

        GameObject hole = CreateBulletHoleAtImpact(contact);

        SetChildParent(hole, collision.gameObject);

    }

    private GameObject CreateBulletHoleAtImpact(ContactPoint contact)
    {
        GameObject hole = Instantiate(
            GlobalReferences.Instance.bulletImpactEffectPrefab,
            contact.point - (-contact.normal * 0.005f),
            Quaternion.LookRotation(-contact.normal)
        );
        return hole;

    }

    private void SetChildParent(GameObject child, GameObject parent)
    {
        child.transform.SetParent(parent.transform);

    }
}
