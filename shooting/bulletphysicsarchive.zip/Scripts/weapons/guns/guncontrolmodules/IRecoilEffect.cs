using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IRecoilEffect {

    Quaternion CalculateRecoilRotation(float recoilIntensity, float recoilIntensityModifier, Transform recoilingObject); 
}
