using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SingleInputController : IWeaponController
{
    public bool GetWeaponInput()
    {
        return Input.GetKeyDown(KeyCode.Mouse0);
    }
}