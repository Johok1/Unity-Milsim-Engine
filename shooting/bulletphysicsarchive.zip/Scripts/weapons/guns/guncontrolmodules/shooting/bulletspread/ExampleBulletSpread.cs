using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExampleBulletSpread : IBulletSpread
{
    public Vector3 ApplySpreadOverTime(Vector3 direction, float spreadIntensity, float spreadModifier)
    {
        float spreadX = UnityEngine.Random.Range(-spreadIntensity, spreadIntensity) * (spreadModifier);
        float spreadY = UnityEngine.Random.Range(-spreadIntensity, spreadIntensity) * (spreadModifier);


        return direction + new Vector3(spreadX, spreadY, 0);
    }

}
